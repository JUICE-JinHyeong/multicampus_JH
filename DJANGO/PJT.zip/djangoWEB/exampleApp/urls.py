from django.contrib import admin
from django.urls import path , include

from exampleApp import views

urlpatterns = [
    # http://localhost:800/greeting/index/
    path("index/", views.index),
]


