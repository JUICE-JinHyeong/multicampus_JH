from django.contrib import admin
from django.urls import path , include

from bootApp import views

urlpatterns = [
    # http://localhost:8000/boot/
    path("",            views.index),
    path("grammar/",    views.grammar),
    path("table/",      views.table),
    path("basic/",      views.basic),
    path("navigator/",  views.navigator),
]


