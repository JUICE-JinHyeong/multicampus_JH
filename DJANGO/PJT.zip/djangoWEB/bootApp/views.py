from django.shortcuts import render

# Create your views here.

def index(request) :
    print('debug >>>>>>>>>>>>>> boot index')
    return render(request , 'boot/index.html')

def grammar(request) :
    print('debug >>>>>>>>>>>>>> boot grammar')
    return render(request , 'boot/grammar.html')

def table(request) :
    print('debug >>>>>>>>>>>>>> boot table')
    return render(request , 'boot/table.html')

def basic(request) :
    print('debug >>>>>>>>>>>>>> boot basic')
    return render(request , 'boot/basic.html')

def navigator(request) :
    print('debug >>>>>>>>>>>>>> boot navigator')
    return render(request , 'boot/navigator.html')
