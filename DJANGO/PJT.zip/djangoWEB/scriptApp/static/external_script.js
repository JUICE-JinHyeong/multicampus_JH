
function sayEcho() {
    window.alert('안녕하세요~ 자바스크립트 입니다.');
}
