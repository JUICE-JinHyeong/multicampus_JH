from django.contrib import admin
from django.urls import path , include

from scriptApp import views

urlpatterns = [
    # http://localhost:8000/css/
    path("",                views.index),
    path("grammar/",        views.grammar),
    path("dom/",            views.dom),
    path("dom_form/",       views.dom_form),
    path("jquery/",         views.jquery),
    path("dom_control/",    views.dom_control),
]

