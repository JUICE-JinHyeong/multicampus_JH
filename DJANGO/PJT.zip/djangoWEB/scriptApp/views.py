from django.shortcuts import render

# Create your views here.

def index(request) :
    print('debug >>>>>> script index')
    return render(request , 'script/index.html')

def grammar(request) :
    print('debug >>>>>> script grammar')
    return render(request, 'script/grammar.html')

def dom(request) :
    print('debug >>>>>> script dom')
    return render(request, 'script/dom.html')

def dom_form(request) :
    print('debug >>>>>> script dom_form')
    return render(request, 'script/dom_form.html')

def jquery(request) :
    print('debug >>>>>> script jquery')
    return render(request, 'script/jquery.html')


def dom_control(request) :
    print('debug >>>>>> script dom_control')
    return render(request, 'script/dom_control.html')











