from django.contrib import admin
from django.urls import path , include

from cssApp import views

urlpatterns = [
    # http://localhost:8000/css/
    path("",            views.index),
    # http://localhost:8000/css/grammar
    path("grammar/",                views.grammar),
    path("selector/",               views.selector),
    path("combine_selector/",       views.composit),
    path("box/",                    views.box),
    path("layout/",                 views.layout),
    path("float/",                  views.float),
]

