from django.shortcuts import render

# Create your views here.

def index(request) :
    print('debug >>>>>>>>>> css index')
    return render(request, 'css/index.html')

def grammar(request) :
    print('debug >>>>>>>>>> css grammar')
    return render(request, 'css/grammar.html')

def selector(request) :
    print('debug >>>>>>>>>> css selector')
    return render(request, 'css/selector.html')

def composit(request) :
    print('debug >>>>>>>>>> css combine_selector')
    return render(request, 'css/combine_selector.html')

def box(request) :
    print('debug >>>>>>>>>> css box')
    return render(request, 'css/box.html')


def layout(request) :
    print('debug >>>>>>>>>> css layout')
    return render(request, 'css/layout.html')

def float(request) :
    print('debug >>>>>>>>>> css float')
    return render(request, 'css/float.html')







