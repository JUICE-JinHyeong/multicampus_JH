from django.contrib import admin
from django.urls import path , include

from htmlApp import views

urlpatterns = [
    # http://localhost:8000/html/
    path("",            views.index),
    # http://localhost:8000/html/grammar
    path("grammar/",    views.grammar),
    # http://localhost:8000/html/layout
    path("layout/",     views.layout),
    path("move/",       views.move),
    path("list/",       views.list),
    path("table/",      views.table),
    path("form/",       views.form),
    path("login/",      views.login),
]
